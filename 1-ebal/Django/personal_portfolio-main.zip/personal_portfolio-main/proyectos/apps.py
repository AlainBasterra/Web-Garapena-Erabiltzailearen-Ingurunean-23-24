from django.apps import AppConfig


class ProyectosConfig(AppConfig):
    name = 'proyectos'
